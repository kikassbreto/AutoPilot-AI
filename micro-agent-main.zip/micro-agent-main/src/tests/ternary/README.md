## Simplify ternary test

Run with the below command:

```bash
npm start -- src/tests/ternary/simplify.ts -t "npm test ternary && npm run typecheck"
```
