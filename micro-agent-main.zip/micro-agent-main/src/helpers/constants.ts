import pkg from '../../package.json';

export const commandName = 'micro-agent';
export const projectName = 'Micro Agent';
export const repoUrl = pkg.repository.url;
